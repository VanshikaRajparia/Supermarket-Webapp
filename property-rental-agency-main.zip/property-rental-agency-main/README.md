# property-rental-agency
Oracle SQL Database Functionalities
Created procedures for various tasks using Oracle SQL. Some functionalities include add/remove properties from the database by the tenant or company manager, renting the same property to different tenants over different periods and getting the rent history for a particular property.
